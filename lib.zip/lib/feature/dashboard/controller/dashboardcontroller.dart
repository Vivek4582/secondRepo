import 'package:get/get.dart';
import 'package:untitled/core/routes.dart';

class DashboardController extends GetxController{
  gotologin(){
    Get.toNamed(Routes.login);
  }

}