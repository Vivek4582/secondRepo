import 'package:get/get.dart';
import 'package:untitled/core/routes.dart';

class SlideController extends GetxController{
  nextto(){
    Get.toNamed(Routes.dashboard);
  }

}