class URLConstant{
  static const String baseUrl = 'https://ubiattendance.ubiattendance.xyz/newpanel/index.php/Att_services_getx_xyz_regendra/';
  static const String signup = "insertDataTest?";
  static const String login = "loginDataTest?";
  static const String deleteDataIntern = "deleteDataTest?";
  static const String TimeIn = 'flutterInternsAtt?';
  static const String TimeOut = 'flutterInternsAttOut?';
  static const String Deatilfetch = 'fetchDataTest?';
  static const String updatedata = 'updateDataTest?';
  static const String detailfetch = 'updateDataFlutterIntern?';






}

