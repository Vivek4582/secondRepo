class Routes{
  static String login='/loginview.dart';
  static String splash='/splashview.dart';
  static String dashboard='/dashboardview.dart';
  static String slider='/sliderview.dart';
  static String signup='/signupview.dart';
  static String verify='/verifyview.dart';
  static String detail='/detailview.dart';
  static String profile='/profile_view.dart';











}